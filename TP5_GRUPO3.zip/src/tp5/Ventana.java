package tp5;

public interface Ventana {

	// Establece una medida y posicion para la ventana

	int posX = 450;
	int posY = 150;
	int ancho = 450;
	int alto = 300;

	void hacerVisible();
}